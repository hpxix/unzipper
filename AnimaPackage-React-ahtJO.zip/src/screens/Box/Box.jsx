import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <img className="img" alt="Img" src="/img/image.svg" />
    </div>
  );
};
